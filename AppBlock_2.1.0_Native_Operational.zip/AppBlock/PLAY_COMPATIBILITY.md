# App Block 2.0 — Play/Android Compatibility Notes

## Design choices
- Target SDK 36 / Android API 36.
- AccessibilityService is used only for the disclosed foreground protection function.
- UsageStats is used for local usage accounting and limits.
- No QUERY_ALL_PACKAGES permission.
- No Device Administrator.
- No prevention of Android Settings access.
- No prevention of uninstalling App Block.
- No Play Protect bypass or security-control bypass.
- Notifications use normal Android notification permission on Android 13+.
- Battery optimization is detected and explained rather than silently altered.

## Accessibility disclosure
The onboarding flow states that Accessibility is used to detect selected foreground apps and present the blocking screen during active protection. The user can disable the service from Android Settings.

## Website protection disclosure
Website protection currently depends on supported browsers exposing address-bar information through Accessibility events. It is not presented as a universal network firewall. A future VPN-based network filter would require a separate architecture and review.

## Release requirement
Play Console declarations, privacy policy, Data Safety answers, store listing, screenshots and the current Google Play policies must be reviewed before publication. Source compatibility does not guarantee Play approval.
