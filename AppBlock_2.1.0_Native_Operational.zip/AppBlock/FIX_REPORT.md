# App Block 2.0.0 — Operational Rebuild Report

## Major changes
1. Reworked the Protection Core into a deterministic decision engine with explicit reasons.
2. Added reusable BlockList entities and schedule-to-blocklist assignment.
3. Added per-app unlock grants and protected-session restrictions.
4. Added timezone-aware recurring/one-time/overnight schedule evaluation.
5. Added full-week minute-grid conflict detection for schedules.
6. Added foreground UsageStats reconstruction for daily limits.
7. Added persistent focus sessions and process-recoverable timer/break state.
8. Added real session-break state that relaxes protection without unlocking configuration.
9. Added persistent block-event history.
10. Added persistent daily/weekly goals and correct weekly progress.
11. Added Accessibility heartbeat and Protection Health diagnostics.
12. Added app discovery through launcher queries plus UsageStats-visible packages without QUERY_ALL_PACKAGES.
13. Added persistent profile name.
14. Added start/end schedule notifications and recovery scheduling.
15. Added versioned backup schema including rules, schedules, sessions, history and goals.
16. Updated UI to expose Protection Health, Blocklists, Quick Block and reusable schedule rules.
17. Updated disclosure and help text to accurately describe Accessibility and website limitations.
18. Kept Play-sensitive controls out: no Settings blocking, uninstall prevention, Device Admin or Play Protect bypass.

## Static validation
- Kotlin source was parsed with the local Kotlin compiler; no syntax/parse errors remained in the source pass.
- XML resources were parsed successfully.
- Placeholder/TODO scan completed.
- Old 1.5.0 application version strings removed from source UI/build metadata.

## Build limitation
A complete Android Gradle build and real-device test could not be performed in this workspace because the Android SDK/Gradle Android toolchain was unavailable. This is explicitly not claimed as an APK build success.
