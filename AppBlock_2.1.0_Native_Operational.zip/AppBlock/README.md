# App Block 2.0.0 — Operational Protection Build

App Block is a native Android application built with Kotlin and Jetpack Compose—not an HTML/web front end. Its protection path runs through Android AccessibilityService and UsageStats, while rules, schedules, sessions, history, goals and backups are persisted locally.

## Core behavior
- Focus, Strict, Study, Sleep and Custom modes.
- Multiple reusable blocklists with duplication and always-active rules.
- Per-app daily limits plus a default limit for selected apps.
- Recurring and one-time schedules, including overnight schedules and time zones.
- Protected Focus Sessions with configuration locking.
- Real session breaks: app/website protection temporarily relaxes while rule configuration remains locked.
- Per-app temporary unlock grants with expiry; protected sessions cannot be overridden.
- Quick Block for immediate protected sessions.
- Persistent block-event and focus-session history.
- Daily/weekly goals and streaks.
- Protection Health diagnostics and Accessibility heartbeat.
- Reboot/time-change schedule recovery.
- Versioned local backup/export with encrypted backup support.
- Browser address-bar website/domain protection with explicit non-firewall disclosure.

## Android/Play design
- Target/compile SDK 36.
- No QUERY_ALL_PACKAGES permission.
- No Device Administrator.
- No Play Protect bypass.
- No Android Settings blocking.
- No uninstall prevention.
- Accessibility use is disclosed and user-controlled.
- Usage data is read locally.

## Important limitation
AccessibilityService is event-driven and Android controls its lifecycle. App Block therefore exposes protection health and interruption diagnostics instead of claiming impossible uninterrupted system-level enforcement. Website rules use browser address-bar accessibility detection and are not a universal network firewall.

## Build
Open the `AppBlock` folder in Android Studio and sync with a current Android SDK/Gradle environment. This workspace did not contain the Android SDK, so APK/device execution was not possible here.

## Validation files
- `V2_ACCEPTANCE_MATRIX.md` — maps the 20 user complaints to implemented behavior.
- `REAL_DEVICE_TEST_PLAN.md` — required physical-device validation matrix.
- `PLAY_COMPATIBILITY.md` — Play/Android design constraints.


## Operational implementation notes
- The UI is native Jetpack Compose and calls a Kotlin ViewModel/repository; there is no WebView or HTML application layer.
- Blocking decisions are made by `BlockingEngine` and the Accessibility service launches the native `BlockedActivity`.
- Usage limits are calculated from Android `UsageStatsManager` foreground/background events.
- Schedules are evaluated in their stored IANA timezone and support overnight boundaries.
- Protected sessions lock rule/configuration changes.
- Blocklists can be edited individually for apps and websites and reused by schedules.
- The blocked screen does not return the user directly to the blocked app when Back is pressed; it sends the task to the launcher.
- Android permissions remain user-controlled; the app does not attempt to bypass Android or Play Protect controls.

## Build status
The source project is complete enough for Android Studio/Gradle compilation, but this artifact was not APK-tested in the generation environment because an Android SDK/build toolchain was unavailable there. Physical Android 12–16 testing remains required before production release.
