# App Block 2.0 — Complaint Acceptance Matrix

This build treats the 20 user complaints as product acceptance requirements.

1. Trustable protection — Accessibility heartbeat, health screen, interruption reporting, deterministic Protection Core.
2. Bypass resistance — foreground package checks, duplicate-launch cooldown, per-app unlock grants, protected-session lock.
3. Website honesty/capability — normalized domain matching, browser address-bar detection, explicit non-firewall wording.
4. Usage accuracy — foreground/background event reconstruction and current-session accounting.
5. Study mode — separate mode semantics plus selected rules and known distraction detection.
6. Mode differentiation — Focus/Strict/Study/Sleep/Custom have distinct documented decision behavior.
7. Temporary unlock — per-app grant support, expiry, protected-session prohibition, unlock policy.
8. Block screen — reason, matched rule/domain, protected-session state, why-blocked dialog.
9. Schedule clarity — recurring/one-time/overnight/time-zone-aware schedules and conflict rejection.
10. Always active — blocklists support always-active rules.
11. Quick Block — one-action protected quick block.
12. Dashboard — protection state, focus, blocked apps, websites, streak, health entry points.
13. Event history — persisted block events with reason/details.
14. Recovery — reboot/time-change receiver plus heartbeat and diagnostics.
15. Battery restrictions — detected and reported as a health warning.
16. App discovery — launcher apps plus packages surfaced by UsageStats, without QUERY_ALL_PACKAGES.
17. Blocklist duplication — independent reusable blocklists with duplicate support.
18. Backup confidence — versioned JSON schema with rules, schedules, sessions, history and goals.
19. Capability transparency — onboarding and help explain Accessibility/UsageStats and website limitations.
20. Product trust — no Play Protect bypass, Settings blocking, uninstall prevention or deceptive Accessibility use.

## Additional operational fixes
- Protected-session configuration lock is centralized across rules, blocklists, schedules, websites and data import/delete.
- Breaks are real protection states: configuration remains locked while selected app/website blocking is temporarily relaxed.
- Profile name is persisted.
- Weekly goal uses weekly session data instead of today's total.
- Schedule blocklists can be selected when creating a schedule.
- Schedule conflicts are evaluated across the complete weekly minute grid so overnight cross-day overlaps are caught.
