package com.appblock.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.appblock.R
import com.appblock.data.AppBlockRepository

class AppBlockNotificationReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent){val manager=context.getSystemService(NotificationManager::class.java);manager.createNotificationChannel(NotificationChannel("app_block_schedule","Schedule",NotificationManager.IMPORTANCE_DEFAULT));manager.createNotificationChannel(NotificationChannel("app_block_warning","Protection warnings",NotificationManager.IMPORTANCE_HIGH));manager.createNotificationChannel(NotificationChannel("app_block_summary","Daily summary",NotificationManager.IMPORTANCE_LOW));val type=intent.getStringExtra("type")?:"start";val channel=if(type=="warning")"app_block_warning"else if(type=="summary")"app_block_summary"else"app_block_schedule";manager.notify((System.currentTimeMillis()%Int.MAX_VALUE).toInt(),NotificationCompat.Builder(context,channel).setSmallIcon(R.drawable.ic_app_block).setContentTitle(intent.getStringExtra("title")?:"App Block").setContentText(intent.getStringExtra("message")?:"Your protection state changed.").setAutoCancel(true).build());val id=intent.getLongExtra("scheduleId",-1);if(id!=-1)AppBlockRepository(context).schedules().firstOrNull{it.id==id}?.let{if(it.enabled&&it.oneTimeDate==null)NotificationScheduler.schedule(context,it)}}
}
