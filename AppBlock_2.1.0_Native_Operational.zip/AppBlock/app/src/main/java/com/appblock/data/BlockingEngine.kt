package com.appblock.data

import android.content.Context
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/** Central protection decision engine. No UI or Accessibility work is performed here. */
class BlockingEngine(context:Context){
    private val appContext=context.applicationContext
    private val repo=AppBlockRepository(appContext)
    private val usage=UsageStatsReader(appContext)

    fun decision(packageName:String,now:Calendar=Calendar.getInstance()):BlockDecision{
        if(packageName.isBlank()||packageName==appContext.packageName)return BlockDecision.allow()
        val s=repo.settings(); if(!s.focusEnabled)return BlockDecision.allow()
        if(s.sessionBreakUntil>System.currentTimeMillis())return BlockDecision.allow()
        if(repo.temporaryUnlockUntil()>System.currentTimeMillis()&&!isProtected(s))return BlockDecision.allow()
        val unlock=repo.unlocks().firstOrNull{it.packageName==packageName&&it.expiresAt>System.currentTimeMillis()}
        if(unlock!=null && !isProtected(s))return BlockDecision.allow()

        val activeSchedules=repo.schedules().filter{it.enabled&&isScheduleActive(it,now)}
        val activeLists=repo.blockLists().filter{it.enabled&&(it.alwaysActive||activeSchedules.any{sch->sch.blockListIds.isEmpty()||sch.blockListIds.contains(it.id)})}
        val selected=repo.blockedApps().firstOrNull{it.packageName==packageName}
        val listMatch=activeLists.firstOrNull{it.packageNames.contains(packageName)}
        val usageMinutes=usage.minutesToday(packageName)
        val limit=selected?.dailyLimitMinutes?:0

        if(isProtected(s)){
            if(selected?.allowedDuringProtected==true)return BlockDecision.allow()
            if(listMatch!=null)return BlockDecision(true,BlockReason.PROTECTED_SESSION,"Protected Focus Session • ${listMatch.name}",listMatch.name)
            if(selected?.blocked==true)return BlockDecision(true,BlockReason.PROTECTED_SESSION,"Protected Focus Session",selected.name)
        }
        if(limit>0&&usageMinutes>=limit)return BlockDecision(true,BlockReason.DAILY_LIMIT,"${usageMinutes} / ${limit} minutes used today",selected?.name)
        if(s.dailyLimit>0&&selected!=null&&usageMinutes>=s.dailyLimit)return BlockDecision(true,BlockReason.DAILY_LIMIT,"${usageMinutes} / ${s.dailyLimit} minutes used today",selected.name)
        if(listMatch!=null)return BlockDecision(true,BlockReason.APP_RULE,"Blocklist: ${listMatch.name}",listMatch.name)

        return when(s.mode){
            BlockMode.STRICT -> if(selected?.blocked!=false)BlockDecision(true,BlockReason.MODE,"Strict Mode: app is not explicitly allowed") else BlockDecision.allow()
            BlockMode.STUDY -> if(selected?.blocked==true||isKnownDistracting(packageName))BlockDecision(true,if(selected?.blocked==true)BlockReason.APP_RULE else BlockReason.MODE,"Study Mode") else BlockDecision.allow()
            BlockMode.FOCUS,BlockMode.SLEEP,BlockMode.CUSTOM -> if(selected?.blocked==true)BlockDecision(true,BlockReason.APP_RULE,"Selected in your blocked apps",selected.name) else BlockDecision.allow()
        }
    }

    fun websiteDecision(domain:String?,now:Calendar=Calendar.getInstance()):BlockDecision{
        if(domain.isNullOrBlank()||!repo.settings().focusEnabled)return BlockDecision.allow()
        val s=repo.settings(); if(s.sessionBreakUntil>System.currentTimeMillis())return BlockDecision.allow(); if(repo.unlocks().any{it.packageName=="__website__"&&it.expiresAt>System.currentTimeMillis()}&&!isProtected(s))return BlockDecision.allow()
        val candidate=WebsiteUrlDetector.normalizeDomain(domain);if(candidate.isBlank())return BlockDecision.allow()
        val schedules=repo.schedules().filter{it.enabled&&isScheduleActive(it,now)}
        val lists=repo.blockLists().filter{it.enabled&&(it.alwaysActive||schedules.any{sch->sch.blockListIds.isEmpty()||sch.blockListIds.contains(it.id)})}
        val rule=lists.firstNotNullOfOrNull{l->l.websites.firstOrNull{r->domainMatches(candidate,r)}?.let{l.name+": "+it}}
            ?:repo.websites().firstOrNull{domainMatches(candidate,it)}
        if(rule!=null)return BlockDecision(true,if(isProtected(s))BlockReason.PROTECTED_SESSION else BlockReason.APP_RULE,"Website rule: $rule",rule)
        return BlockDecision.allow()
    }

    fun isBlockingActive(now:Calendar=Calendar.getInstance()):Boolean=repo.settings().focusEnabled&&(repo.schedules().isEmpty()||repo.schedules().any{it.enabled&&isScheduleActive(it,now)}||repo.blockLists().any{it.enabled&&it.alwaysActive})
    fun shouldBlock(pkg:String,now:Calendar=Calendar.getInstance())=decision(pkg,now).blocked
    fun shouldBlockWebsite(domain:String?,now:Calendar=Calendar.getInstance())=websiteDecision(domain,now).blocked
    fun activeScheduleName(now:Calendar=Calendar.getInstance())=repo.schedules().firstOrNull{it.enabled&&isScheduleActive(it,now)}?.name
    fun validateSchedule(s:BlockSchedule):String?{
        if(s.name.isBlank())return "Schedule needs a name"
        if(s.startMinutes !in 0..1439||s.endMinutes !in 0..1439)return "Schedule time is invalid"
        if(s.oneTimeDate==null&&s.days.isEmpty())return "Choose at least one day"
        if(s.oneTimeDate!=null&&!Regex("\\d{4}-\\d{2}-\\d{2}").matches(s.oneTimeDate))return "Date must use YYYY-MM-DD"
        return null
    }
    fun isScheduleActive(s:BlockSchedule,instant:Long=System.currentTimeMillis()):Boolean=isScheduleActive(s,Calendar.getInstance(TimeZone.getTimeZone(s.timezoneId)).apply{timeInMillis=instant})
    fun isScheduleActive(s:BlockSchedule,now:Calendar):Boolean{
        if(!s.enabled)return false
        val tz=TimeZone.getTimeZone(s.timezoneId)
        val c=now.clone() as Calendar;c.timeZone=tz
        val minute=c.get(Calendar.HOUR_OF_DAY)*60+c.get(Calendar.MINUTE)
        val overnight=s.startMinutes>s.endMinutes
        if(s.oneTimeDate!=null){
            val today=dateKey(c)
            if(today==s.oneTimeDate)return if(!overnight)minute in s.startMinutes..s.endMinutes else minute>=s.startMinutes
            if(overnight){val p=(c.clone() as Calendar).apply{add(Calendar.DAY_OF_YEAR,-1)};return dateKey(p)==s.oneTimeDate&&minute<=s.endMinutes}
            return false
        }
        val day=c.get(Calendar.DAY_OF_WEEK)
        if(!overnight)return s.days.contains(day)&&minute in s.startMinutes..s.endMinutes
        if(s.days.contains(day)&&minute>=s.startMinutes)return true
        val p=(c.clone() as Calendar).apply{add(Calendar.DAY_OF_YEAR,-1)}
        return s.days.contains(p.get(Calendar.DAY_OF_WEEK))&&minute<=s.endMinutes
    }
    fun conflicts(candidate:BlockSchedule,existing:List<BlockSchedule>):Boolean=existing.filter{it.enabled}.any{scheduleCanOverlap(it,candidate)}
    private fun scheduleCanOverlap(a:BlockSchedule,b:BlockSchedule):Boolean{
        if(a.oneTimeDate!=null||b.oneTimeDate!=null){
            if(a.oneTimeDate==null||b.oneTimeDate==null)return false
            if(a.oneTimeDate!=b.oneTimeDate)return false
            return (0 until 1440).any{m->activeOnDay(a,Calendar.MONDAY,m)&&activeOnDay(b,Calendar.MONDAY,m)}
        }
        // Evaluate the complete weekly cycle. This correctly catches overnight cross-day overlap.
        for(day in Calendar.SUNDAY..Calendar.SATURDAY){
            for(minute in 0 until 1440){
                if(activeOnDay(a,day,minute)&&activeOnDay(b,day,minute))return true
            }
        }
        return false
    }
    private fun activeOnDay(s:BlockSchedule,day:Int,minute:Int):Boolean{
        if(s.startMinutes<=s.endMinutes)return s.days.contains(day)&&minute in s.startMinutes..s.endMinutes
        if(s.days.contains(day)&&minute>=s.startMinutes)return true
        val previous=if(day==Calendar.SUNDAY)Calendar.SATURDAY else day-1
        return s.days.contains(previous)&&minute<=s.endMinutes
    }
    private fun intervals(s:BlockSchedule ):List<IntRange> =if(s.startMinutes<=s.endMinutes)listOf(s.startMinutes..s.endMinutes)else listOf(s.startMinutes..1439,0..s.endMinutes)
    private fun domainMatches(candidate:String,rule:String):Boolean{val r=WebsiteUrlDetector.normalizeRule(rule)?:return false;return candidate==r||candidate.endsWith(".$r")}
    private fun isProtected(s:AppSettings)=s.protectedSessionUntil>System.currentTimeMillis()
    private fun dateKey(c:Calendar)="%04d-%02d-%02d".format(Locale.US,c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH))
    private fun isKnownDistracting(p:String)=listOf("youtube","instagram","tiktok","facebook","netflix","snapchat","twitter","reddit","discord").any{p.contains(it,true)}
}

data class BlockDecision(val blocked:Boolean,val reason:BlockReason?=null,val detail:String="",val matchedRule:String?=null){companion object{fun allow()=BlockDecision(false)}}
