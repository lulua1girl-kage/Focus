package com.appblock.service

import android.content.Intent
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.appblock.data.AppBlockRepository
import com.appblock.data.BlockMode

class BlockedActivity:Activity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val pkg=intent.getStringExtra("package").orEmpty();val repo=AppBlockRepository(this);val app=repo.blockedApps().firstOrNull{it.packageName==pkg};val reason=intent.getStringExtra("reason").orEmpty();val domain=intent.getStringExtra("domain");val rule=intent.getStringExtra("rule");val detail=intent.getStringExtra("detail").orEmpty();val title=if(reason=="website")"Website blocked" else "${app?.name?:pkg} is blocked";val why=when{reason=="website"->"${domain?:("This website")} matches ${rule?:"a blocked website rule"}.";detail.isNotBlank()->detail;else->repo.settings().mode.label};val s=repo.settings();val canUnlock=s.allowTemporaryUnlock&&s.mode!=BlockMode.STRICT&&s.protectedSessionUntil<=System.currentTimeMillis();val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(48,48,48,48);setBackgroundColor(Color.rgb(6,16,28))};root.addView(TextView(this).apply{text="🔒";textSize=64f;gravity=Gravity.CENTER});root.addView(TextView(this).apply{text=title;textSize=28f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(0,16,0,12)});root.addView(TextView(this).apply{text=why;textSize=16f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER});root.addView(Button(this).apply{text="Why is this blocked?";setOnClickListener{android.app.AlertDialog.Builder(this@BlockedActivity).setTitle("Protection reason").setMessage(why).setPositiveButton("OK",null).show()}},params(36));root.addView(Button(this).apply{text="Back";setOnClickListener{startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));finish()}},params(8));if(canUnlock&&reason!="website")root.addView(Button(this).apply{text="Unlock this app • 5 min";setOnClickListener{repo.saveUnlocks(repo.unlocks().filter{it.packageName!=pkg}+com.appblock.data.UnlockGrant(pkg,System.currentTimeMillis()+5*60_000,"User temporary unlock"));finish()}},params(8))else root.addView(TextView(this).apply{text=if(s.protectedSessionUntil>System.currentTimeMillis())"Protected session is active. Temporary unlock is unavailable." else "Temporary unlock is disabled by your current protection policy.";textSize=14f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER;setPadding(0,16,0,0)});setContentView(root)}
 private fun params(top:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{topMargin=top}
}
