package com.appblock

import android.app.Application
import android.app.AppOpsManager
import android.os.Build
import android.view.accessibility.AccessibilityManager
import android.accessibilityservice.AccessibilityServiceInfo
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.appblock.data.*
import com.appblock.service.NotificationScheduler
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class AppBlockViewModel(app:Application):AndroidViewModel(app){
    private val repo=AppBlockRepository(app);private val installedRepo=InstalledAppRepository(app);private val engine=BlockingEngine(app);private val usageReader=UsageStatsReader(app)
    var settings by mutableStateOf(repo.settings());private set
    var blockedApps by mutableStateOf(repo.blockedApps());private set
    var blockLists by mutableStateOf(repo.blockLists());private set
    var schedules by mutableStateOf(repo.schedules());private set
    var websites by mutableStateOf(repo.websites().toList().sorted());private set
    var installedApps by mutableStateOf(installedRepo.apps());private set
    var sessions by mutableStateOf(repo.focusSessions());private set
    var blockEvents by mutableStateOf(repo.blockEvents());private set
    var goals by mutableStateOf(repo.goals());private set
    var serviceRunning by mutableStateOf(false);private set
    var usageAccess by mutableStateOf(false);private set
    var batteryOptimized by mutableStateOf(true);private set
    var lastProtectionEventAt by mutableStateOf(0L);private set
    var selectedAppPackage by mutableStateOf<String?>(null);private set
    var searchQuery by mutableStateOf("");private set
    var timerRunning by mutableStateOf(false);private set
    var timerPaused by mutableStateOf(false);private set
    var timerRemainingSeconds by mutableStateOf(0L);private set
    var breakRunning by mutableStateOf(false);private set
    var breakRemainingSeconds by mutableStateOf(0L);private set
    private var timerTotalSeconds=0L;private var timerStartedAt=0L;private var breakStartedAt=0L;private var breakTotalSeconds=0L
    var temporaryUnlockUntil by mutableStateOf(repo.temporaryUnlockUntil());private set
    var profileName by mutableStateOf(app.getSharedPreferences("app_block_profile",0).getString("name","App Block User")?:"App Block User");private set

    init{restoreTimerState();refreshInstalledApps();refreshPermissionState();viewModelScope.launch{while(isActive){if(timerRunning&&!timerPaused&&!breakRunning)tickTimer();if(breakRunning)tickBreak();refreshTemporaryUnlock();delay(1000)}}}

    private val timerPrefs get()=getApplication<Application>().getSharedPreferences("app_block_timer",0)
    private fun restoreTimerState(){val p=timerPrefs;timerStartedAt=p.getLong("startedAt",0);timerTotalSeconds=p.getLong("total",0);timerPaused=p.getBoolean("paused",false);timerRemainingSeconds=p.getLong("remaining",0);breakRunning=p.getBoolean("breakRunning",false);breakStartedAt=p.getLong("breakStarted",0);breakTotalSeconds=p.getLong("breakTotal",0);breakRemainingSeconds=p.getLong("breakRemaining",0);timerRunning=timerTotalSeconds>0&&timerRemainingSeconds>0;if(timerRunning&&!timerPaused&&!breakRunning){timerRemainingSeconds=(timerTotalSeconds-((System.currentTimeMillis()-timerStartedAt)/1000)).coerceAtLeast(0);if(timerRemainingSeconds==0L)finishTimer(true)}}
    private fun persistTimer(){timerPrefs.edit().putLong("startedAt",timerStartedAt).putLong("total",timerTotalSeconds).putBoolean("paused",timerPaused).putLong("remaining",timerRemainingSeconds).putBoolean("breakRunning",breakRunning).putLong("breakStarted",breakStartedAt).putLong("breakTotal",breakTotalSeconds).putLong("breakRemaining",breakRemainingSeconds).apply()}
    private fun clearTimer(){timerPrefs.edit().clear().apply()}
    private fun tickTimer(){timerRemainingSeconds=(timerTotalSeconds-((System.currentTimeMillis()-timerStartedAt)/1000)).coerceAtLeast(0L);persistTimer();if(timerRemainingSeconds==0L)finishTimer(true)}
    private fun tickBreak(){breakRemainingSeconds=(breakTotalSeconds-((System.currentTimeMillis()-breakStartedAt)/1000)).coerceAtLeast(0L);persistTimer();if(breakRemainingSeconds==0L){breakRunning=false;updateSettings(settings.copy(sessionBreakUntil=0L));timerStartedAt=System.currentTimeMillis()-(timerTotalSeconds-timerRemainingSeconds)*1000;persistTimer()}}

    fun refreshInstalledApps(){installedApps=installedRepo.apps()}
    fun refreshPermissionState(){val c=getApplication<Application>();usageAccess=runCatching{val op=c.getSystemService(AppOpsManager::class.java);op.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,android.os.Process.myUid(),c.packageName)==AppOpsManager.MODE_ALLOWED}.getOrDefault(false);val access=runCatching{val m=c.getSystemService(AccessibilityManager::class.java);m.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any{it.resolveInfo.serviceInfo.packageName==c.packageName}}.getOrDefault(false);serviceRunning=access; batteryOptimized=if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M)!(c.getSystemService(android.os.PowerManager::class.java)?.isIgnoringBatteryOptimizations(c.packageName)?:false) else false;refreshTemporaryUnlock()}
    fun protectionHealth():List<HealthCheck>{refreshPermissionState();val now=System.currentTimeMillis();return listOf(HealthCheck("access","Accessibility protection",serviceRunning,if(serviceRunning)"Service is enabled"else"Enable Accessibility Service"),HealthCheck("usage","Usage Access",usageAccess,if(usageAccess)"UsageStats can be read"else"Grant Usage Access"),HealthCheck("rules","Rule engine",true,"Protection rules are loaded"),HealthCheck("schedule","Schedule engine",schedules.none{engine.validateSchedule(it)!=null},if(schedules.none{engine.validateSchedule(it)!=null})"Schedules validate"else"One or more schedules are invalid"),HealthCheck("heartbeat","Protection heartbeat",settings.protectionHeartbeatAt>now-10*60_000,"Last service heartbeat: "+if(settings.protectionHeartbeatAt==0L)"never" else "${(now-settings.protectionHeartbeatAt)/1000}s ago"),HealthCheck("battery","Battery restrictions",!batteryOptimized,if(batteryOptimized)"Battery optimization may interrupt protection"else"No battery optimization restriction detected"),HealthCheck("data","Local data",settings.localOnlyData,"Data stays on this device"),HealthCheck("website","Website rules",true,"Browser address-bar detection is enabled"))}
    fun runProtectionTest():List<HealthCheck>{refreshPermissionState();val checks=protectionHealth();if(serviceRunning)repo.heartbeat(true);return checks}
    fun setSearch(v:String){searchQuery=v};fun toggleFocus(){if(!isProtectedSessionActive())updateSettings(settings.copy(focusEnabled=!settings.focusEnabled))};fun setMode(v:BlockMode){if(!isProtectedSessionActive())updateSettings(settings.copy(mode=v))};fun setLimit(v:Int){if(!isProtectedSessionActive())updateSettings(settings.copy(dailyLimit=v.coerceIn(0,600)))};fun toggleNotifications(){if(!isProtectedSessionActive())updateSettings(settings.copy(notifications=!settings.notifications))};fun toggleSound(){if(!isProtectedSessionActive())updateSettings(settings.copy(soundEnabled=!settings.soundEnabled))};fun toggleVibration(){if(!isProtectedSessionActive())updateSettings(settings.copy(vibrationEnabled=!settings.vibrationEnabled))};fun setDarkMode(v:Boolean){if(!isProtectedSessionActive())updateSettings(settings.copy(darkMode=v))};fun setTemporaryUnlockAllowed(v:Boolean){if(!isProtectedSessionActive())updateSettings(settings.copy(allowTemporaryUnlock=v))};fun setBreakMinutes(v:Int){if(!isProtectedSessionActive())updateSettings(settings.copy(breakMinutes=v.coerceIn(0,60)))};fun setClock24Hour(v:Boolean){if(!isProtectedSessionActive())updateSettings(settings.copy(clock24Hour=v))};fun setTimezone(v:String){if(!isProtectedSessionActive())updateSettings(settings.copy(timezoneId=v))};fun finishOnboarding()=updateSettings(settings.copy(onboardingComplete=true,disclosureAccepted=true));fun acceptDisclosure()=updateSettings(settings.copy(disclosureAccepted=true));fun resetOnboarding()=updateSettings(settings.copy(onboardingComplete=false));fun setServiceRunning(v:Boolean){serviceRunning=v}
    fun saveProfileName(v:String){profileName=v.trim().ifBlank{"App Block User"};getApplication<Application>().getSharedPreferences("app_block_profile",0).edit().putString("name",profileName).apply()}
    fun isProtectedSessionActive()=settings.protectedSessionUntil>System.currentTimeMillis();fun startProtectedSession(minutes:Int){if(minutes>0)updateSettings(settings.copy(protectedSessionUntil=System.currentTimeMillis()+minutes*60_000L))};fun endProtectedSession(){updateSettings(settings.copy(protectedSessionUntil=0L))}
    fun isBlocked(pkg:String)=engine.shouldBlock(pkg);fun blockDecision(pkg:String)=engine.decision(pkg);fun isWebsiteBlocked(domain:String)=engine.shouldBlockWebsite(domain);fun selectedApp()=blockedApps.firstOrNull{it.packageName==selectedAppPackage};fun openApp(pkg:String){selectedAppPackage=pkg}

    fun toggleApp(pkg:String){if(isProtectedSessionActive())return;val a=installedApps.firstOrNull{it.packageName==pkg}?:return;val old=blockedApps.firstOrNull{it.packageName==pkg};val next=if(old==null){BlockedApp(pkg,a.name,a.category,if(settings.mode==BlockMode.STRICT)false else true)}else old.copy(blocked=!old.blocked);blockedApps=if(old==null)blockedApps+next else blockedApps.map{if(it.packageName==pkg)next else it};repo.saveBlockedApps(blockedApps)}
    fun setExplicitlyAllowed(pkg:String,allowed:Boolean){if(isProtectedSessionActive())return;val a=installedApps.firstOrNull{it.packageName==pkg}?:return;val existing=blockedApps.firstOrNull{it.packageName==pkg};val next=if(existing==null)BlockedApp(pkg,a.name,a.category,!allowed)else existing.copy(blocked=!allowed);blockedApps=if(existing==null)blockedApps+next else blockedApps.map{if(it.packageName==pkg)next else it};repo.saveBlockedApps(blockedApps)}
    fun setAppLimit(pkg:String,minutes:Int){if(isProtectedSessionActive())return;val a=installedApps.firstOrNull{it.packageName==pkg}?:return;val m=minutes.coerceAtLeast(0);blockedApps=if(blockedApps.none{it.packageName==pkg})blockedApps+BlockedApp(pkg,a.name,a.category,false,m)else blockedApps.map{if(it.packageName==pkg)it.copy(dailyLimitMinutes=m)else it};repo.saveBlockedApps(blockedApps)}
    fun setAllowedDuringProtected(pkg:String,allowed:Boolean){if(isProtectedSessionActive())return;blockedApps=blockedApps.map{if(it.packageName==pkg)it.copy(allowedDuringProtected=allowed)else it};repo.saveBlockedApps(blockedApps)}

    fun createBlockList(name:String,category:String="Custom",always:Boolean=false):Boolean{if(isProtectedSessionActive()||name.isBlank())return false;if(blockLists.any{it.name.equals(name,true)})return false;val n=BlockList(System.currentTimeMillis(),name,emptySet(),emptySet(),true,always,category);blockLists=blockLists+n;repo.saveBlockLists(blockLists);return true}
    fun duplicateBlockList(id:Long):Boolean{if(isProtectedSessionActive())return false;val old=blockLists.firstOrNull{it.id==id}?:return false;val n=old.copy(id=System.currentTimeMillis(),name=old.name+" Copy",enabled=true);blockLists=blockLists+n;repo.saveBlockLists(blockLists);return true}
    fun toggleBlockList(id:Long){if(isProtectedSessionActive())return;blockLists=blockLists.map{if(it.id==id)it.copy(enabled=!it.enabled)else it};repo.saveBlockLists(blockLists)}
    fun deleteBlockList(id:Long){if(isProtectedSessionActive())return;blockLists=blockLists.filterNot{it.id==id};repo.saveBlockLists(blockLists)}
    fun addWebsiteToBlockList(id:Long,value:String){if(isProtectedSessionActive())return;val clean=WebsiteUrlDetector.normalizeRule(value)?:return;blockLists=blockLists.map{if(it.id==id)it.copy(websites=it.websites+clean)else it};repo.saveBlockLists(blockLists)}
    fun removeWebsiteFromBlockList(id:Long,value:String){if(isProtectedSessionActive())return;blockLists=blockLists.map{if(it.id==id)it.copy(websites=it.websites-value)else it};repo.saveBlockLists(blockLists)}
    fun addAppToList(id:Long,pkg:String){if(isProtectedSessionActive())return;blockLists=blockLists.map{if(it.id==id)it.copy(packageNames=it.packageNames+pkg)else it};repo.saveBlockLists(blockLists)}
    fun removeAppFromList(id:Long,pkg:String){if(isProtectedSessionActive())return;blockLists=blockLists.map{if(it.id==id)it.copy(packageNames=it.packageNames-pkg)else it};repo.saveBlockLists(blockLists)}
    fun addWebsiteToList(id:Long,value:String){if(isProtectedSessionActive())return;val clean=WebsiteUrlDetector.normalizeRule(value)?:return;blockLists=blockLists.map{if(it.id==id)it.copy(websites=it.websites+clean)else it};repo.saveBlockLists(blockLists)}
    fun removeWebsiteFromList(id:Long,value:String){if(isProtectedSessionActive())return;blockLists=blockLists.map{if(it.id==id)it.copy(websites=it.websites-value)else it};repo.saveBlockLists(blockLists)}

    fun addWebsite(v:String){if(isProtectedSessionActive())return;val clean=WebsiteUrlDetector.normalizeRule(v)?:return;websites=(websites+clean).distinct().sorted();repo.saveWebsites(websites.toSet())};fun removeWebsite(v:String){if(isProtectedSessionActive())return;websites=websites-v;repo.saveWebsites(websites.toSet())}
    fun toggleSchedule(id:Long){if(isProtectedSessionActive())return;val u=schedules.map{if(it.id==id)it.copy(enabled=!it.enabled)else it};schedules=u;repo.saveSchedules(u);u.firstOrNull{it.id==id}?.let{if(it.enabled)NotificationScheduler.schedule(getApplication(),it)else NotificationScheduler.cancel(getApplication(),it)}}
    fun addSchedule(name:String,days:Set<Int>,start:Int,end:Int,oneTimeDate:String?=null,blockListIds:Set<Long> = emptySet(),breakMinutes:Int=settings.breakMinutes):Boolean{if(isProtectedSessionActive())return false;val s=BlockSchedule(System.currentTimeMillis(),name.ifBlank{"Focus Schedule"},days,start,end,true,oneTimeDate,blockListIds,settings.timezoneId,breakMinutes);if(engine.validateSchedule(s)!=null||engine.conflicts(s,schedules))return false;schedules=schedules+s;repo.saveSchedules(schedules);NotificationScheduler.schedule(getApplication(),s);return true}
    fun deleteSchedule(id:Long){if(isProtectedSessionActive())return;schedules.firstOrNull{it.id==id}?.let{NotificationScheduler.cancel(getApplication(),it)};schedules=schedules.filterNot{it.id==id};repo.saveSchedules(schedules)}

    fun quickBlock(minutes:Int){if(isProtectedSessionActive())return;val safe=minutes.coerceIn(1,24*60);startProtectedSession(safe)}
    fun startTimer(minutes:Int){if(isProtectedSessionActive())return;val safe=minutes.coerceIn(1,24*60);timerTotalSeconds=safe*60L;timerRemainingSeconds=timerTotalSeconds;timerStartedAt=System.currentTimeMillis();timerPaused=false;breakRunning=false;persistTimer();timerRunning=true;startProtectedSession(safe)}
    fun pauseTimer(){if(timerRunning&&!timerPaused&&!breakRunning){timerPaused=true;timerRemainingSeconds=(timerTotalSeconds-((System.currentTimeMillis()-timerStartedAt)/1000)).coerceAtLeast(0L);persistTimer()}}
    fun resumeTimer(){if(timerRunning&&timerPaused&&timerRemainingSeconds>0){timerStartedAt=System.currentTimeMillis()-(timerTotalSeconds-timerRemainingSeconds)*1000;timerPaused=false;persistTimer()}}
    fun startBreak(){if(!timerRunning||timerPaused||breakRunning)return;val mins=schedules.firstOrNull{it.enabled&&engine.isScheduleActive(it)}?.breakMinutes?:settings.breakMinutes;if(mins<=0)return;breakTotalSeconds=mins*60L;breakRemainingSeconds=breakTotalSeconds;breakStartedAt=System.currentTimeMillis();breakRunning=true;updateSettings(settings.copy(sessionBreakUntil=System.currentTimeMillis()+breakTotalSeconds*1000));persistTimer()}
    fun stopBreak(){if(!breakRunning)return;breakRunning=false;updateSettings(settings.copy(sessionBreakUntil=0L));timerStartedAt=System.currentTimeMillis()-(timerTotalSeconds-timerRemainingSeconds)*1000;persistTimer()}
    fun stopTimer(){if(timerRunning)finishTimer(false)}
    private fun finishTimer(completed:Boolean){if(!timerRunning)return;val elapsed=((timerTotalSeconds-timerRemainingSeconds)/60).toInt().coerceAtLeast(0);if(elapsed>0){sessions=(sessions+FocusSession(System.currentTimeMillis(),timerStartedAt,elapsed,completed,timerTotalSeconds.toInt()/60,0,!completed)).takeLast(500);repo.saveFocusSessions(sessions)};timerRunning=false;timerPaused=false;breakRunning=false;timerRemainingSeconds=0;breakRemainingSeconds=0;clearTimer();updateSettings(settings.copy(sessionBreakUntil=0L));endProtectedSession()}

    fun unlockFor(minutes:Int):Boolean{if(!settings.allowTemporaryUnlock||settings.mode==BlockMode.STRICT||isProtectedSessionActive())return false;val until=System.currentTimeMillis()+minutes.coerceIn(1,30)*60_000L;temporaryUnlockUntil=until;repo.saveTemporaryUnlockUntil(until);return true}
    fun unlockAppFor(pkg:String,minutes:Int=5):Boolean{if(!settings.allowTemporaryUnlock||settings.mode==BlockMode.STRICT||isProtectedSessionActive())return false;val g=UnlockGrant(pkg,System.currentTimeMillis()+minutes.coerceIn(1,30)*60_000L,"User temporary unlock");repo.saveUnlocks(repo.unlocks().filter{it.packageName!=pkg}+g);return true}
    fun temporaryUnlockActive()=System.currentTimeMillis()<temporaryUnlockUntil;fun refreshTemporaryUnlock(){temporaryUnlockUntil=repo.temporaryUnlockUntil()}
    fun filteredApps()=installedApps.filter{searchQuery.isBlank()||it.name.contains(searchQuery,true)||it.category.contains(searchQuery,true)}
    fun blockedCount()=blockedApps.count{it.blocked};fun focusMinutesToday()=sessions.filter{it.startedAt>=startOfDay()}.sumOf{it.durationMinutes};fun weeklyFocusMinutes()=sessions.filter{it.startedAt>=startOfWeek()}.sumOf{it.durationMinutes}
    fun streak():Int{val d=sessions.filter{it.completed}.map{SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(it.startedAt))}.toSet();var n=0;val c=Calendar.getInstance();while(d.contains(SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.time))){n++;c.add(Calendar.DAY_OF_YEAR,-1)};return n}
    fun usageSnapshot()=usageReader.today();fun goalProgressToday()=if(goals.dailyFocusMinutes<=0)0f else(focusMinutesToday().toFloat()/goals.dailyFocusMinutes).coerceIn(0f,1f);fun goalProgressWeek()=if(goals.weeklyFocusMinutes<=0)0f else(weeklyFocusMinutes().toFloat()/goals.weeklyFocusMinutes).coerceIn(0f,1f)
    fun saveGoals(daily:Int,weekly:Int,enabled:Boolean=true){if(!isProtectedSessionActive()){goals=GoalSettings(daily.coerceIn(5,1440),weekly.coerceIn(5,10080),enabled);repo.saveGoals(goals)}}
    fun recentBlockEvents(limit:Int=50)=blockEvents.take(limit);fun exportData()=repo.exportJson();fun exportEncryptedBackup(password:String)=BackupCrypto.encrypt(repo.exportJson(),password.toCharArray());fun importData(raw:String){if(isProtectedSessionActive())return;repo.importJson(raw);reload()};fun importEncryptedBackup(raw:String,password:String){if(isProtectedSessionActive())return;repo.importJson(BackupCrypto.decrypt(raw,password.toCharArray()));reload()};fun deleteAllData(){if(isProtectedSessionActive())return;repo.clearAll();clearTimer();reload()}
    fun reload(){settings=repo.settings();blockedApps=repo.blockedApps();blockLists=repo.blockLists();schedules=repo.schedules();websites=repo.websites().toList().sorted();sessions=repo.focusSessions();blockEvents=repo.blockEvents();goals=repo.goals();refreshInstalledApps();refreshTemporaryUnlock()}
    private fun updateSettings(v:AppSettings){settings=v;repo.saveSettings(v)};private fun startOfDay()=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis;private fun startOfWeek()=Calendar.getInstance().apply{set(Calendar.DAY_OF_WEEK,firstDayOfWeek);set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
}
