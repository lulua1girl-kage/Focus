package com.appblock

import android.Manifest
import android.app.*
import android.content.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.activity.viewModels
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.appblock.data.*
import com.appblock.service.NotificationScheduler
import java.text.SimpleDateFormat
import java.util.*

private val Bg = Color(0xFF06101C); private val Card = Color(0xFF0D1B2B); private val Blue = Color(0xFF3198FF); private val Muted = Color(0xFF8DA1B8); private val Good = Color(0xFF66D9A0)

class MainActivity : ComponentActivity() {
    private val appViewModel: AppBlockViewModel by viewModels()
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AppBlockTheme(appViewModel.settings.darkMode) { AppBlockApp(notificationPermission, appViewModel) } } }
    override fun onResume() { super.onResume(); appViewModel.refreshPermissionState() }
}

@Composable fun AppBlockTheme(dark: Boolean, content: @Composable () -> Unit) = MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Blue, onBackground = Color.White, onSurface = Color.White), content = content)

@Composable fun AppBlockApp(notificationPermission: androidx.activity.result.ActivityResultLauncher<String>, vm: AppBlockViewModel) {
    if (!vm.settings.onboardingComplete) Onboarding(vm) else {
        val nav = rememberNavController(); val entry by nav.currentBackStackEntryAsState()
        Scaffold(bottomBar = { BottomBar(nav, entry?.destination?.route) }, containerColor = Bg) { p ->
            NavHost(nav, startDestination = "home", modifier = Modifier.padding(p)) {
                composable("home") { Home(vm, nav) }; composable("apps") { Apps(vm, nav) }; composable("schedule") { Schedule(vm, nav) }
                composable("scheduleEditor") { ScheduleEditor(vm, nav) }; composable("stats") { Stats(vm, nav) }; composable("settings") { Settings(vm, nav, notificationPermission) }
                composable("timer") { Timer(vm, nav) }; composable("modes") { Modes(vm) }; composable("websites") { Websites(vm) }; composable("limits") { Limits(vm, nav) }
                composable("notifications") { Notifications(vm, notificationPermission) }; composable("privacy") { Privacy(vm) }; composable("setup") { ProtectionSetup(vm, notificationPermission) }; composable("help") { Help(nav) }
                composable("service") { ServiceSetup(vm) }; composable("health") { ProtectionHealth(vm) }; composable("blocklists") { BlockLists(vm, nav) }; composable("blocklistEditor/{id}") { back -> BlockListEditor(vm, nav, back.arguments?.getString("id")?.toLongOrNull() ?: -1L) }; composable("profile") { Profile(vm) }; composable("blocked") { BlockedScreen(vm, nav) }
                composable("goals") { Goals(vm) }; composable("usageHistory") { UsageHistory() }; composable("focusHistory") { FocusHistory(vm) }
                composable("appDetails/{pkg}") { back -> AppDetails(vm, nav, Uri.decode(back.arguments?.getString("pkg") ?: "")) }
            }
        }
    }
}

@Composable fun Onboarding(vm: AppBlockViewModel) {
    var accepted by rememberSaveable { mutableStateOf(vm.settings.disclosureAccepted) }
    Box(Modifier.fillMaxSize().background(Bg).padding(24.dp), Alignment.Center) {
        Column(horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(14.dp)) {
            Text("🔒", fontSize=72.sp); Text("App Block", fontSize=34.sp, fontWeight=FontWeight.Bold); Text("Your focus. Your future.", color=Muted, fontSize=18.sp)
            CardBox {
                Text("Before you start", fontWeight=FontWeight.Bold, fontSize=18.sp)
                Text("App Block uses Android Accessibility to detect selected apps and show the block screen during an active session. Usage Access is used only for usage statistics and time limits. Notifications are optional.", color=Muted)
                Text("You control these permissions in Android Settings. App Block does not disable Play Protect, block Android Settings, or prevent you from uninstalling the app.", color=Muted)
                Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(accepted, { accepted = it }); Text("I understand and agree to this permission disclosure.", fontSize=13.sp) }
            }
            PrimaryButton(if(accepted) "Continue" else "Review disclosure") { if(accepted) vm.finishOnboarding() }
            Text("You can review these explanations later in Protection Setup.", color=Muted, fontSize=12.sp)
        }
    }
}

@Composable fun Home(vm: AppBlockViewModel, nav: NavHostController) { Page("Good evening 👋", "Stay focused. Your goals matter.") {
    CardBox { Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) { Column(Modifier.weight(1f)){Text(vm.settings.mode.label,fontWeight=FontWeight.Bold);Text(if(vm.settings.focusEnabled) "Protection is active" else "Focus is paused",color=Muted,fontSize=12.sp)};Switch(vm.settings.focusEnabled,{vm.toggleFocus()}) } }
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("Blocked Apps",vm.blockedCount().toString());Stat("Today's Focus","${vm.focusMinutesToday()}m")}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("Websites",vm.websites.size.toString());Stat("Streak","${vm.streak()} day")}
    Text("Quick Actions",fontWeight=FontWeight.Bold); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Action("Add App"){nav.navigate("apps")};Action("Quick Block"){vm.quickBlock(15)};Action("Focus Timer"){nav.navigate("timer")};Action("Schedule"){nav.navigate("scheduleEditor")}}
    Text("Protection",fontWeight=FontWeight.Bold); ListButton("Protection Setup","Permissions, disclosure and Android status"){nav.navigate("setup")}; ListButton("Protection Health","Run the real protection self-test"){nav.navigate("health")}; ListButton("Blocklists","Independent app and website rule sets"){nav.navigate("blocklists")}; if(vm.isProtectedSessionActive()) CardBox{Text("Protected Focus Session",fontWeight=FontWeight.Bold);Text("Your blocking rules are protected until the timer ends.",color=Muted);TextButton({vm.endProtectedSession();vm.stopTimer()}){Text("End protected session")}}; Text("Controls",fontWeight=FontWeight.Bold); ListButton("Blocking Modes",vm.settings.mode.label){nav.navigate("modes")};ListButton("Website Blocking","${vm.websites.size} domains"){nav.navigate("websites")};ListButton("Time Limits","${vm.settings.dailyLimit} min/day"){nav.navigate("limits")};ListButton("Service Setup",if(hasAccessibilityService(LocalContext.current))"Running" else "Needs setup"){nav.navigate("service")}; ListButton("Protection Health","Diagnostics and recovery"){nav.navigate("health")}
} }

@Composable fun Apps(vm: AppBlockViewModel, nav: NavHostController) { Page("App Library", "Choose launchable apps to block or allow. No broad app-inventory permission is requested.") { SearchBar(vm.searchQuery,"Search installed apps...",vm::setSearch); Text("${vm.filteredApps().size} apps",color=Muted); LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.heightIn(max=520.dp)){items(vm.filteredApps(),key={it.packageName}){a->CardBox{Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth().clickable{nav.navigate("appDetails/${Uri.encode(a.packageName)}")}){Column(Modifier.weight(1f)){Text(a.name,fontWeight=FontWeight.Medium);Text(a.category,color=Muted,fontSize=12.sp)};if(vm.settings.mode==BlockMode.STRICT){Row(verticalAlignment=Alignment.CenterVertically){Text("Allow",color=Muted,fontSize=12.sp);Switch(vm.blockedApps.any{it.packageName==a.packageName&&it.blocked==false},{vm.setExplicitlyAllowed(a.packageName,it)})}}else Switch(vm.blockedApps.any{it.packageName==a.packageName&&it.blocked},{vm.toggleApp(a.packageName)})}}}} } }

@Composable fun AppDetails(vm: AppBlockViewModel, nav: NavHostController, pkg:String) { val app=vm.installedApps.firstOrNull{it.packageName==pkg}; val blocked=vm.blockedApps.firstOrNull{it.packageName==pkg}; Page(app?.name ?: "App Details",app?.category ?: pkg){var limit by rememberSaveable(pkg){mutableStateOf(blocked?.dailyLimitMinutes ?: 0)};CardBox{Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){Column(Modifier.weight(1f)){Text("Block App",fontWeight=FontWeight.Bold);Text(if(blocked?.blocked==true)"Currently blocked" else "Currently allowed",color=Muted,fontSize=12.sp)};Switch(blocked?.blocked==true,{vm.toggleApp(pkg)})}};Text("Daily time limit",fontWeight=FontWeight.Bold);Row(verticalAlignment=Alignment.CenterVertically){Slider(value=limit.toFloat(), onValueChange={limit=it.toInt()}, valueRange=0f..360f, modifier=Modifier.weight(1f));Text("${limit}m",modifier=Modifier.width(55.dp))};PrimaryButton("Save App Settings"){vm.setAppLimit(pkg,limit);nav.popBackStack()};ListButton("Allow During Schedule","Controlled by current mode"){vm.setMode(BlockMode.CUSTOM)};ListButton("Show Notifications","Use global notification setting"){nav.navigate("notifications")} }
}

@Composable fun Schedule(vm: AppBlockViewModel, nav: NavHostController) { Page("Schedule","Automate your focus sessions."){PrimaryButton("＋ Add Schedule"){nav.navigate("scheduleEditor")};if(vm.schedules.isEmpty())EmptyState("No schedules yet","Create a schedule to automate blocking."){nav.navigate("scheduleEditor")};vm.schedules.forEach{s->CardBox{Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){Column(Modifier.weight(1f)){Text(s.name,fontWeight=FontWeight.Bold);Text("${daysLabel(s.days)} • ${formatMinutes(s.startMinutes)} – ${formatMinutes(s.endMinutes)}",color=Muted,fontSize=12.sp)};Switch(s.enabled,{vm.toggleSchedule(s.id)});IconButton({vm.deleteSchedule(s.id)}){Icon(Icons.Default.Delete,"Delete")}}};ListButton("Schedule details","${if(s.enabled)"Active"else"Paused"}"){nav.navigate("scheduleEditor")}}} }

@Composable fun ScheduleEditor(vm:AppBlockViewModel,nav:NavHostController){val ctx=LocalContext.current;var name by rememberSaveable{mutableStateOf("Study Time")};var oneTime by rememberSaveable{mutableStateOf("")};var start by rememberSaveable{mutableStateOf("08:00")};var end by rememberSaveable{mutableStateOf("12:00")};var days by rememberSaveable{mutableStateOf(setOf(2,3,4,5,6))};var selectedLists by rememberSaveable{mutableStateOf(emptySet<Long>())};Page("Create Schedule","Choose when protection activates and which blocklists it controls."){OutlinedTextField(name,{name=it},label={Text("Name")},modifier=Modifier.fillMaxWidth());OutlinedTextField(start,{start=it},label={Text("Start (HH:MM)")},modifier=Modifier.fillMaxWidth());OutlinedTextField(end,{end=it},label={Text("End (HH:MM)")},modifier=Modifier.fillMaxWidth());OutlinedTextField(oneTime,{oneTime=it},label={Text("One-time date (YYYY-MM-DD, optional)")},modifier=Modifier.fillMaxWidth());Text("Days",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){(1..7).forEach{d->FilterChip(selected=days.contains(d),onClick={days=if(days.contains(d))days-d else days+d},label={Text(dayShort(d))})}};Text("Blocklists",fontWeight=FontWeight.Bold);if(vm.blockLists.isEmpty())Text("No blocklists yet. The schedule will use the normal app rules.",color=Muted) else vm.blockLists.forEach{l->FilterChip(selected=selectedLists.contains(l.id),onClick={selectedLists=if(selectedLists.contains(l.id))selectedLists-l.id else selectedLists+l.id},label={Text(l.name)})};PrimaryButton("Save Schedule"){val a=parseMinutes(start);val b=parseMinutes(end);if(a!=null&&b!=null){if(vm.addSchedule(name,days,a,b,oneTime.ifBlank{null},selectedLists)){nav.popBackStack()}else showInfo(ctx,"Schedule not saved","Check the time, date, selected days, blocklist selection, or an overlapping schedule.")}};OutlinedButton({nav.popBackStack()},Modifier.fillMaxWidth()){Text("Cancel")}}}

@Composable fun Stats(vm: AppBlockViewModel, nav:NavHostController){val ctx=LocalContext.current;var period by rememberSaveable{mutableStateOf("Daily")};val usage=when(period){"Weekly"->remember(period){UsageStatsReader(ctx).week()};"Monthly"->remember(period){UsageStatsReader(ctx).month()};else->remember(period){UsageStatsReader(ctx).today()}};Page("Usage Statistics","Real Android UsageStats data when Usage Access is granted."){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Daily","Weekly","Monthly").forEach{FilterChip(selected=period==it,onClick={period=it},label={Text(it)})}};CardBox{Text("Screen Time",fontWeight=FontWeight.Bold);Text(if(usage.isEmpty())"Grant Usage Access to measure" else "${usage.sumOf{it.minutes}}m",fontSize=30.sp,fontWeight=FontWeight.Bold);Text(if(usage.isEmpty())"No usage data available yet" else "Live from Android",color=Good)};Text("Top Apps",fontWeight=FontWeight.Bold);usage.take(6).forEach{CardBox{Row(Modifier.fillMaxWidth()){Text(it.name,Modifier.weight(1f));Text("${it.minutes}m",color=Muted)}}};ListButton("Usage History","Today and recent usage"){nav.navigate("usageHistory")};ListButton("Focus History","Completed sessions"){nav.navigate("focusHistory")};ListButton("Goals & Streaks","Daily goals and achievements"){nav.navigate("goals")}}}

@Composable fun Timer(vm:AppBlockViewModel,nav:NavHostController){Page("Focus Timer","A persistent countdown with protected rules and optional breaks."){ if(vm.isProtectedSessionActive()) CardBox{Text("Protected Focus Session",fontWeight=FontWeight.Bold);Text("Rule changes are paused while this session is active.",color=Muted)};Text(formatSeconds(vm.timerRemainingSeconds),fontSize=46.sp,fontWeight=FontWeight.Bold,modifier=Modifier.fillMaxWidth());if(vm.breakRunning){CardBox{Text("Break active",fontWeight=FontWeight.Bold);Text(formatSeconds(vm.breakRemainingSeconds),fontSize=32.sp);PrimaryButton("End break"){vm.stopBreak()}}} else if(!vm.timerRunning)PrimaryButton("Start 25 min"){vm.startTimer(25)}else if(vm.timerPaused)PrimaryButton("Resume"){vm.resumeTimer()}else PrimaryButton("Pause"){vm.pauseTimer()};if(vm.timerRunning&&!vm.timerPaused&&!vm.breakRunning&&vm.settings.breakMinutes>0)OutlinedButton({vm.startBreak()},Modifier.fillMaxWidth()){Text("Start ${vm.settings.breakMinutes}-minute break")};OutlinedButton({vm.stopTimer()},Modifier.fillMaxWidth()){Text("Stop")};ListButton("Blocked Apps","${vm.blockedCount()} apps selected"){nav.navigate("apps")};ListButton("Session History","${vm.sessions.size} sessions"){nav.navigate("focusHistory")}}}

@Composable
fun Modes(vm:AppBlockViewModel){
    Page("Blocking Modes","Each mode changes how the Protection Core evaluates apps."){
        BlockMode.values().forEach { m ->
            CardBox {
                Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth().clickable{vm.setMode(m)}) {
                    Column(Modifier.weight(1f)) { Text(m.label,fontWeight=FontWeight.Bold); Text(m.description,color=Muted,fontSize=12.sp) }
                    RadioButton(selected=vm.settings.mode==m,onClick={vm.setMode(m)})
                }
            }
        }
        if(vm.settings.mode==BlockMode.STRICT) Text("Strict blocks discovered apps unless you explicitly allow them.",color=Muted)
    }
}

@Composable fun Websites(vm:AppBlockViewModel){var input by rememberSaveable{mutableStateOf("")};Page("Website Blocking","Add domains to block when they are entered in a supported browser address bar."){Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(input,{input=it},label={Text("Domain")},modifier=Modifier.weight(1f));IconButton({vm.addWebsite(input);input=""}){Icon(Icons.Default.Add,"Add")}};Text("Blocked Websites",fontWeight=FontWeight.Bold);vm.websites.forEach{w->CardBox{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(w,Modifier.weight(1f));IconButton({vm.removeWebsite(w)}){Icon(Icons.Default.Close,"Remove")}}}};ListButton("Social Media","Domain rules"){vm.addWebsite("facebook.com")};ListButton("Entertainment","Domain rules"){vm.addWebsite("youtube.com")}}}

@Composable fun Limits(vm:AppBlockViewModel,nav:NavHostController){Page("Time Limits","Set the default limit used for selected apps, plus per-app limits."){Text("Default per-app daily limit: ${vm.settings.dailyLimit} minutes",fontSize=22.sp,fontWeight=FontWeight.Bold);Slider(value=vm.settings.dailyLimit.toFloat(), onValueChange={vm.setLimit(it.toInt())}, valueRange=5f..360f);PrimaryButton("Save"){nav.popBackStack()};ListButton("Per-App Limits","Configure a different limit from App Details"){nav.navigate("apps")};CardBox{Text("A limit is enforced using Android UsageStats plus the blocking service when permissions are available.",color=Muted)}}}

@Composable fun Notifications(vm:AppBlockViewModel,launcher:androidx.activity.result.ActivityResultLauncher<String>){Page("Notifications","Real Android notification controls."){SwitchRow("Notifications",vm.settings.notifications){vm.toggleNotifications()};SwitchRow("Sound",vm.settings.soundEnabled){vm.toggleSound()};SwitchRow("Vibration",vm.settings.vibrationEnabled){vm.toggleVibration()};if(Build.VERSION.SDK_INT>=33)PrimaryButton("Grant Notification Permission"){launcher.launch(Manifest.permission.POST_NOTIFICATIONS)};Text("Schedule notifications are created when schedules are saved.",color=Muted)}}

@Composable fun Settings(vm:AppBlockViewModel,nav:NavHostController,launcher:androidx.activity.result.ActivityResultLauncher<String>){val ctx=LocalContext.current;Page("Settings","Control your App Block experience."){ListButton("Profile","Edit profile and achievements"){nav.navigate("profile")};ListButton("Blocking Settings","Modes, apps and websites"){nav.navigate("modes")};ListButton("Appearance",if(vm.settings.darkMode)"Dark Mode" else "Light Mode"){showAppearanceDialog(ctx,vm)};ListButton("Language","English"){showInfo(ctx,"Language","English is currently the available interface language.")};ListButton("Sound & Vibration","${if(vm.settings.soundEnabled)"Sound"else"Silent"}"){nav.navigate("notifications")};ListButton("Notifications","Customize alerts"){nav.navigate("notifications")};ListButton("Privacy & Data","Backup, export and delete"){nav.navigate("privacy")};ListButton("Service Setup",if(hasAccessibilityService(LocalContext.current))"Running"else"Needs setup"){nav.navigate("service")};ListButton("Help & Support","FAQ and troubleshooting"){nav.navigate("help")}}}

@Composable fun ServiceSetup(vm:AppBlockViewModel){ val ctx=LocalContext.current; val usage=hasUsageAccess(ctx); val access=hasAccessibilityService(ctx); val battery=hasBatteryOptimizationExemption(ctx); LaunchedEffect(access,usage,battery){vm.setServiceRunning(access)}; Page("Service Setup","Android permissions used for blocking and statistics."){
    StatusCard("Usage Access",usage){ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))}
    StatusCard("Accessibility Service",access){ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}
    StatusCard("Battery Optimization",battery){runCatching{ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))}}
    CardBox{Text("Why Accessibility?",fontWeight=FontWeight.Bold);Text("It lets App Block detect when a selected app is opened and show the block screen during an active session. It is not used to read passwords or messages.",color=Muted)}
    CardBox{Text("Your control",fontWeight=FontWeight.Bold);Text("You can disable Accessibility at any time in Android Settings. App Block never disables Play Protect, blocks Android Settings, or prevents uninstalling the app.",color=Muted)}
    if(!access||!usage)Text("Protection is limited until the required permissions are enabled.",color=Color(0xFFFFC857)) else Text("Protection is ready. The AccessibilityService enforces active app rules.",color=Good)
}}

@Composable fun ProtectionSetup(vm:AppBlockViewModel, launcher:androidx.activity.result.ActivityResultLauncher<String>){ val ctx=LocalContext.current; val usage=hasUsageAccess(ctx); val access=hasAccessibilityService(ctx); val battery=hasBatteryOptimizationExemption(ctx); val notifications=Build.VERSION.SDK_INT < 33 || androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled(); Page("Protection Setup","Transparent permissions and Android controls. You decide which optional features to enable."){
    CardBox{Text("Setup status",fontWeight=FontWeight.Bold);Text("${listOf(access,usage,notifications).count{it}} / 3 permission checks ready",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Accessibility is required for blocking. Usage Access is required for live usage statistics and limits. Notifications are optional.",color=Muted)}
    StatusCard("Accessibility — required for blocking",access){ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}
    StatusCard("Usage Access — statistics & limits",usage){ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))}
    StatusCard("Notifications — optional",notifications){if(Build.VERSION.SDK_INT>=33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) else ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,ctx.packageName))}
    StatusCard("Battery Optimization — optional recommendation",battery){ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))}
    CardBox{Text("Permission disclosure",fontWeight=FontWeight.Bold);Text("App Block uses only the Android capabilities needed for the features you enable. App usage data is read locally from UsageStats. No broad QUERY_ALL_PACKAGES permission or Device Administrator is requested.",color=Muted);TextButton({showInfo(ctx,"Accessibility disclosure","Accessibility is used to detect selected foreground apps and present the App Block screen during active blocking. You can disable it at any time in Android Settings.")}){Text("Read full explanation")}; TextButton({showInfo(ctx,"Privacy policy","App Block is local-first. Core blocking does not require a cloud account. UsageStats is read on-device. Encrypted backups are created only when you explicitly export them.")}){Text("Privacy details")}}
    CardBox{Text("Play Protect / Android safety",fontWeight=FontWeight.Bold);Text("App Block is designed to work with Play Protect enabled and does not attempt to bypass Android security controls.",color=Good)}
}}

@Composable
fun Privacy(vm: AppBlockViewModel) {
    val ctx = LocalContext.current
    var pendingExport by remember { mutableStateOf(false) }
    var pendingImport by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            ctx.contentResolver.openOutputStream(uri)?.use { output ->
                output.write(vm.exportEncryptedBackup(rememberedBackupPassword).toByteArray())
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                runCatching { vm.importEncryptedBackup(reader.readText(), rememberedBackupPassword) }
                    .onFailure {
                        showInfo(ctx, "Backup could not be opened", "The password may be incorrect or the backup may be invalid.")
                    }
            }
        }
    }

    Page("Privacy & Backup", "Local-first storage. Export or restore only when you choose.") {
        CardBox {
            Text("Local-first by default", fontWeight = FontWeight.Bold)
            Text("Rules, schedules and focus history stay on this device. Android UsageStats is read on-device. No cloud account is required for core blocking.", color = Muted)
        }
        ListButton("Data Privacy", "What App Block stores and why") {
            showInfo(ctx, "Data Privacy", "App Block stores blocking rules, schedules and focus history locally. UsageStats is read on-device when permission is granted. The core blocker does not require a cloud account.")
        }
        ListButton("Encrypted Backup", "Password-protected backup for settings and rules") { pendingExport = true }
        ListButton("Restore Encrypted Backup", "Import a password-protected backup") { pendingImport = true }
        ListButton("Export Data", "Create a plain JSON copy for your own inspection") {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_TEXT, vm.exportData())
            }
            ctx.startActivity(Intent.createChooser(send, "Share App Block data"))
        }
        ListButton("Delete Local Data", "Clear App Block rules, schedules and history") { vm.deleteAllData() }
    }

    if (pendingExport) {
        showPasswordDialog(ctx, "Create encrypted backup") { password ->
            pendingExport = false
            rememberedBackupPassword = password
            exportLauncher.launch("app-block-backup.abk")
        }
    }
    if (pendingImport) {
        showPasswordDialog(ctx, "Open encrypted backup") { password ->
            pendingImport = false
            rememberedBackupPassword = password
            importLauncher.launch(arrayOf("application/octet-stream", "application/json", "text/plain"))
        }
    }
}

private var rememberedBackupPassword: String = ""



@Composable fun BlockLists(vm:AppBlockViewModel,nav:NavHostController){val ctx=LocalContext.current;var name by rememberSaveable{mutableStateOf("")};var always by rememberSaveable{mutableStateOf(false)};Page("Blocklists","Independent rule sets that can be reused by schedules."){Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(name,{name=it},label={Text("New blocklist")},modifier=Modifier.weight(1f));Switch(always,{always=it});IconButton({if(vm.createBlockList(name,if(name.contains("study",true))"Study" else "Custom",always)){name="";always=false}}){Icon(Icons.Default.Add,"Create")}};if(vm.blockLists.isEmpty())CardBox{Text("No custom blocklists yet",fontWeight=FontWeight.Bold);Text("Create Social Media, Study, Night or Custom lists and assign them to schedules.",color=Muted)};vm.blockLists.forEach{list->CardBox{Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(list.name,fontWeight=FontWeight.Bold);Text("${list.packageNames.size} apps • ${list.websites.size} websites${if(list.alwaysActive)" • Always active"else""}",color=Muted)};Switch(list.enabled,{vm.toggleBlockList(list.id)})};Row{TextButton({vm.duplicateBlockList(list.id)}){Text("Duplicate")};TextButton({vm.deleteBlockList(list.id)}){Text("Delete")}};TextButton({nav.navigate("blocklistEditor/${list.id}")}){Text("Edit rules")}}};Text("Blocklists do not bypass Android security controls. Protected sessions prevent rule edits while active.",color=Muted,fontSize=12.sp)}}

@Composable fun BlockListEditor(vm:AppBlockViewModel,nav:NavHostController,id:Long){
    val list=vm.blockLists.firstOrNull{it.id==id}
    if(list==null){Page("Blocklist not found","This rule set may have been deleted."){PrimaryButton("Back"){nav.popBackStack()}};return}
    var website by rememberSaveable(id){mutableStateOf("")}
    Page(list.name,"Choose exactly which apps and websites belong to this rule set."){
        Text("Apps",fontWeight=FontWeight.Bold)
        SearchBar(vm.searchQuery,"Search apps...",vm::setSearch)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.heightIn(max=360.dp)){
            items(vm.filteredApps(),key={it.packageName}){a->
                CardBox{Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){Column(Modifier.weight(1f)){Text(a.name);Text(a.category,color=Muted,fontSize=12.sp)};Checkbox(list.packageNames.contains(a.packageName),{if(it)vm.addAppToList(id,a.packageName)else vm.removeAppFromList(id,a.packageName)})}}
            }
        }
        Text("Websites",fontWeight=FontWeight.Bold)
        Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(website,{website=it},label={Text("example.com")},modifier=Modifier.weight(1f));IconButton({if(website.isNotBlank()){vm.addWebsiteToBlockList(id,website);website=""}}){Icon(Icons.Default.Add,"Add website")}}
        list.websites.forEach{domain->Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){Text(domain,Modifier.weight(1f));IconButton({vm.removeWebsiteFromBlockList(id,domain)}){Icon(Icons.Default.Delete,"Remove")}}}
        OutlinedButton({nav.popBackStack()},Modifier.fillMaxWidth()){Text("Done")}
    }
}

@Composable fun ProtectionHealth(vm:AppBlockViewModel){val checks=remember{mutableStateListOf<HealthCheck>()};LaunchedEffect(Unit){checks.clear();checks.addAll(vm.runProtectionTest())};Page("Protection Health","A live diagnostic of the systems App Block depends on."){if(checks.isEmpty())Text("Running self-test…",color=Muted);checks.forEach{c->CardBox{Row(verticalAlignment=Alignment.CenterVertically){Text(if(c.ok)"✓"else"⚠",fontSize=24.sp);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(c.title,fontWeight=FontWeight.Bold);Text(c.detail,color=Muted,fontSize=12.sp)}}}};PrimaryButton("Run Test Again"){checks.clear();checks.addAll(vm.runProtectionTest())};Text("If Accessibility is interrupted, App Block cannot silently restart it. The app reports the failure and sends you to the correct Android settings instead.",color=Muted,fontSize=12.sp)}}

@Composable fun Help(nav:NavHostController){val ctx=LocalContext.current;Page("Help & Support","Troubleshoot the features shown in both App Block boards."){ListButton("FAQ","Common questions"){showInfo(ctx,"FAQ","App blocking requires Accessibility Service. Usage statistics require Usage Access. Website matching depends on browser accessibility text.")};ListButton("Troubleshooting","Permission and service checks"){nav.navigate("service")};ListButton("Contact Us","Open your email app"){ctx.startActivity(Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:")))};ListButton("About App Block","Version 2.0.0 • Android"){showInfo(ctx,"About App Block","App Block 2.0.0\nReliable protection rules, schedules, usage limits, history, goals and encrypted local backups.\nAccessibility is used transparently for foreground protection; it is not a universal network firewall.")}}}

@Composable fun Profile(vm:AppBlockViewModel){val ctx=LocalContext.current;Page("Profile","Your focus journey."){CardBox{Text(vm.profileName,fontSize=24.sp,fontWeight=FontWeight.Bold);Text("${vm.streak()} day streak • ${vm.sessions.size} sessions • ${vm.focusMinutesToday()}m today",color=Muted)};ListButton("Edit Profile","Save your display name"){showInput(ctx,"Edit Profile",vm.profileName){vm.saveProfileName(it)}};ListButton("Achievements","View measurable progress"){showInfo(ctx,"Achievements","Focus sessions: ${vm.sessions.size}\nCurrent streak: ${vm.streak()} day\nBlocked attempts: ${vm.blockEvents.size}\nToday: ${vm.focusMinutesToday()} minutes")}}}

@Composable fun Goals(vm:AppBlockViewModel){val ctx=LocalContext.current;Page("Goals & Streaks","Turn focus sessions into measurable progress."){CardBox{Text("Daily focus goal",fontWeight=FontWeight.Bold);Text("${vm.focusMinutesToday()} / ${vm.goals.dailyFocusMinutes} minutes",fontSize=24.sp);LinearProgressIndicator(vm.goalProgressToday(),Modifier.fillMaxWidth())};CardBox{Text("Weekly goal",fontWeight=FontWeight.Bold);Text("${vm.weeklyFocusMinutes()} / ${vm.goals.weeklyFocusMinutes} minutes",fontSize=24.sp);LinearProgressIndicator(vm.goalProgressWeek().coerceIn(0f,1f),Modifier.fillMaxWidth())};Text("Streak: ${vm.streak()} day",fontSize=20.sp,fontWeight=FontWeight.Bold);ListButton("Set goals","Persist your daily and weekly targets"){showInput(ctx,"Daily goal (minutes)",vm.goals.dailyFocusMinutes.toString()){daily->val d=daily.toIntOrNull()?:return@showInput;showInput(ctx,"Weekly goal (minutes)",vm.goals.weeklyFocusMinutes.toString()){weekly->vm.saveGoals(d,weekly)}}}}}

@Composable fun UsageHistory(){val ctx=LocalContext.current;val usage=remember{UsageStatsReader(ctx).today()};Page("Usage History","Android usage data for today."){if(usage.isEmpty())EmptyState("No usage data","Grant Usage Access and use your apps first."){ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))};usage.forEach{CardBox{Row(Modifier.fillMaxWidth()){Text(it.name,Modifier.weight(1f));Text("${it.minutes}m",color=Muted)}}}}}
@Composable fun FocusHistory(vm:AppBlockViewModel){Page("Focus History","Completed focus sessions."){if(vm.sessions.isEmpty())CardBox{Text("No sessions yet",fontWeight=FontWeight.Bold);Text("Start a focus timer to create history.",color=Muted)};vm.sessions.reversed().forEach{CardBox{Column{Text("${it.durationMinutes} minute session",fontWeight=FontWeight.Bold);Text(SimpleDateFormat("MMM d, HH:mm",Locale.getDefault()).format(Date(it.startedAt)),color=Muted)}}}}}

@Composable fun BlockedScreen(vm:AppBlockViewModel,nav:NavHostController){Page("App blocked","You're in ${vm.settings.mode.label}."){Text("Stay focused on your goal.",fontSize=24.sp,fontWeight=FontWeight.Bold);PrimaryButton("Back to Focus"){nav.navigate("timer")};if(vm.settings.allowTemporaryUnlock&&vm.settings.mode!=BlockMode.STRICT&&!vm.isProtectedSessionActive()){OutlinedButton({if(vm.unlockFor(5))nav.navigate("home")},Modifier.fillMaxWidth()){Text("Unlock for 5 minutes")}}else{Text(if(vm.isProtectedSessionActive())"Protected session: temporary unlock is unavailable." else "Temporary unlock is disabled for this mode.",color=Muted)};Text("Temporary unlock expires automatically.",color=Muted)}}

@Composable fun Page(title:String,subtitle:String,content:@Composable ColumnScope.()->Unit){Column(Modifier.fillMaxSize().background(Bg).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text(title,fontSize=27.sp,fontWeight=FontWeight.Bold);Text(subtitle,color=Muted);content();Spacer(Modifier.height(28.dp))}}
@Composable fun CardBox(content:@Composable ColumnScope.()->Unit){Column(Modifier.fillMaxWidth().background(Card,RoundedCornerShape(16.dp)).padding(16.dp),content=content)}
@Composable fun Stat(a:String,b:String){CardBox{Text(a,color=Muted,fontSize=12.sp);Text(b,fontSize=20.sp,fontWeight=FontWeight.Bold)}}
@Composable fun Action(label:String,onClick:()->Unit){Box(Modifier.weight(1f).background(Card,RoundedCornerShape(14.dp)).clickable(onClick=onClick).padding(14.dp),contentAlignment=Alignment.Center){Text(label,fontSize=12.sp)}}
@Composable fun ListButton(title:String,sub:String,onClick:()->Unit){CardBox{Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth().clickable(onClick=onClick)){Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Medium);Text(sub,color=Muted,fontSize=12.sp)};Icon(Icons.Default.ChevronRight,"Open",tint=Muted)}}}
@Composable fun SwitchRow(title:String,checked:Boolean,onChange:()->Unit){CardBox{Row(verticalAlignment=Alignment.CenterVertically){Text(title,Modifier.weight(1f));Switch(checked,onChange)}}}
@Composable fun StatusCard(title:String,ok:Boolean,onClick:()->Unit){CardBox{Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(if(ok)"Enabled"else"Required",color=if(ok)Good else Color(0xFFFFC857))};Button(onClick){Text(if(ok)"Open settings"else"Enable")}}}}
@Composable fun SearchBar(value:String,hint:String,onChange:(String)->Unit){OutlinedTextField(value,onChange,placeholder={Text(hint)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp))}
@Composable fun Segmented(vararg labels:String){Row(Modifier.fillMaxWidth().background(Card,RoundedCornerShape(12.dp)).padding(4.dp),horizontalArrangement=Arrangement.SpaceEvenly){labels.forEach{Text(it,Modifier.padding(10.dp),fontSize=12.sp)}}}
@Composable fun PrimaryButton(label:String,onClick:()->Unit){Button(onClick,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text(label)}}
@Composable fun EmptyState(title:String,subtitle:String,onClick:()->Unit){CardBox{Text(title,fontWeight=FontWeight.Bold);Text(subtitle,color=Muted);TextButton(onClick){Text("Open")}}}
@Composable fun BottomBar(nav:NavHostController,current:String?){NavigationBar(containerColor=Bg){listOf("home" to Icons.Default.Home,"apps" to Icons.Default.Apps,"schedule" to Icons.Default.CalendarMonth,"stats" to Icons.Default.BarChart,"settings" to Icons.Default.Settings).forEach{(route,icon)->NavigationBarItem(selected=current==route,onClick={nav.navigate(route){launchSingleTop=true;popUpTo("home")}},icon={Icon(icon,route)},label={Text(route.replaceFirstChar{it.uppercase()})})}}}

fun hasBatteryOptimizationExemption(context:Context):Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) context.getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(context.packageName) else true
fun hasUsageAccess(context:Context):Boolean = runCatching { val appOps=context.getSystemService(AppOpsManager::class.java); appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,android.os.Process.myUid(),context.packageName)==AppOpsManager.MODE_ALLOWED }.getOrDefault(false)
fun hasAccessibilityService(context:Context):Boolean = runCatching { val manager=context.getSystemService(AccessibilityManager::class.java);manager.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any{it.resolveInfo.serviceInfo.packageName==context.packageName} }.getOrDefault(false)
fun formatSeconds(v:Long)="%02d:%02d:%02d".format(v/3600,(v%3600)/60,v%60)
fun parseMinutes(v:String)=v.split(":").takeIf{it.size==2}?.let{it[0].toIntOrNull()?.times(60)?.plus(it[1].toIntOrNull() ?: 0)}
fun formatMinutes(v:Int)="%02d:%02d".format(v/60,v%60)
fun daysLabel(days:Set<Int>)=days.sorted().joinToString(" "){dayShort(it)}
fun dayShort(d:Int)=listOf("","Sun","Mon","Tue","Wed","Thu","Fri","Sat")[d]
fun showAppearanceDialog(context:Context, vm:AppBlockViewModel){
    val checked = vm.settings.darkMode
    AlertDialog.Builder(context).setTitle("Appearance").setMessage(if(checked) "Dark Mode is active. The App Block design is optimized for dark mode." else "Light Mode is selected.").setPositiveButton(if(checked) "Keep Dark" else "Keep Light",null).setNeutralButton(if(checked) "Switch to Light" else "Switch to Dark"){_,_->vm.setDarkMode(!checked)}.show()
}
fun showPasswordDialog(context:Context,title:String,onSave:(String)->Unit){val input=android.widget.EditText(context).apply{inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD};AlertDialog.Builder(context).setTitle(title).setMessage("Use a password you can remember. App Block never stores it.").setView(input).setPositiveButton("Continue"){_,_->if(input.text.isNotBlank())onSave(input.text.toString())}.setNegativeButton("Cancel",null).show()}
fun showInfo(context:Context,title:String,message:String)=AlertDialog.Builder(context).setTitle(title).setMessage(message).setPositiveButton("OK",null).show()
fun showInput(context:Context,title:String,current:String,onSave:(String)->Unit){val input=android.widget.EditText(context).apply{setText(current)};AlertDialog.Builder(context).setTitle(title).setView(input).setPositiveButton("Save"){_,_->onSave(input.text.toString())}.setNegativeButton("Cancel",null).show()}
