package com.appblock.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.appblock.data.AppBlockRepository

/** Restores scheduled reminder alarms after reboot/timezone changes. Blocking itself remains rule-driven by the accessibility service. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action !in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_TIME_CHANGED)) return
        val repo = AppBlockRepository(context)
        repo.schedules().filter { it.enabled }.forEach { NotificationScheduler.schedule(context, it) }
    }
}
