package com.appblock.data

import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityEvent
import java.net.URI
import java.util.Locale

/**
 * Extracts the current URL/domain from browser address-bar accessibility nodes.
 * It deliberately does NOT scan arbitrary page text, which caused false website blocks in v1.3.
 */
object WebsiteUrlDetector {
    private val knownBrowserPackages = setOf(
        "com.android.chrome",
        "org.mozilla.firefox",
        "com.microsoft.emmx",
        "com.brave.browser",
        "com.opera.browser",
        "com.opera.mini.native",
        "com.vivaldi.browser",
        "com.sec.android.app.sbrowser",
        "com.duckduckgo.mobile.android",
        "com.ecosia.android",
        "com.kiwibrowser.browser",
        "com.ucmobile.intl"
    )

    private val domainPattern = Regex(
        "(?i)(?:https?://)?(?:www\\.)?([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+)"
    )

    fun isBrowserPackage(packageName: String): Boolean = packageName.lowercase(Locale.US) in knownBrowserPackages

    /**
     * Returns a domain only when the accessibility source looks like an address field.
     * This avoids treating normal webpage text, buttons, messages, or article content as URLs.
     */
    fun extractAddressBarDomain(event: AccessibilityEvent, root: AccessibilityNodeInfo?): String? {
        val candidates = ArrayList<String>(4)
        event.source?.let { source -> collectAddressCandidates(source, candidates, HashSet(), 0) }
        if (root != null) collectAddressCandidates(root, candidates, HashSet(), 0)
        return candidates.asSequence()
            .mapNotNull(::extractDomain)
            .map(::normalizeDomain)
            .firstOrNull()
    }

    private fun collectAddressCandidates(
        node: AccessibilityNodeInfo,
        out: MutableList<String>,
        visited: MutableSet<Long>,
        depth: Int
    ) {
        if (depth > 12 || out.size >= 8) return
        val identity = System.identityHashCode(node).toLong()
        if (!visited.add(identity)) return

        val resourceId = node.viewIdResourceName.orEmpty().lowercase(Locale.US)
        val className = node.className?.toString().orEmpty().lowercase(Locale.US)
        val addressLikeId = listOf("url_bar", "urlbar", "address", "omnibox", "location", "url_view")
            .any { resourceId.contains(it) }
        val addressLikeClass = className.contains("edittext") &&
            (addressLikeId || node.isEditable)

        if (addressLikeId || addressLikeClass) {
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        }

        for (i in 0 until node.childCount) {
            if (out.size >= 8) break
            val child = runCatching { node.getChild(i) }.getOrNull() ?: continue
            try {
                collectAddressCandidates(child, out, visited, depth + 1)
            } finally {
                child.recycle()
            }
        }
    }

    private fun extractDomain(raw: String): String? {
        val value = raw.trim().removePrefix("<").removeSuffix(">")
        if (value.isBlank() || value.contains(' ')) return null

        val direct = domainPattern.find(value)?.groupValues?.getOrNull(1)
        if (direct != null) return direct

        val parsed = runCatching {
            val uri = URI(if (value.contains("://")) value else "https://$value")
            uri.host
        }.getOrNull()
        return parsed
    }

    fun normalizeDomain(value: String): String {
        return value.trim().lowercase(Locale.US)
            .removePrefix("https://")
            .removePrefix("http://")
            .removePrefix("www.")
            .substringBefore('/')
            .substringBefore('?')
            .substringBefore('#')
            .trimEnd('.')
    }

    fun normalizeRule(value: String): String? {
        val candidate = normalizeDomain(value)
        if (candidate.isBlank() || candidate.contains(' ') || candidate.contains(':')) return null
        return if (domainPattern.matches(candidate)) candidate else null
    }
}
