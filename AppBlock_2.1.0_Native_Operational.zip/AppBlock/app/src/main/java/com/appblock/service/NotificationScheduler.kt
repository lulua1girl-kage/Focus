package com.appblock.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar
import java.util.TimeZone
import com.appblock.data.BlockSchedule

/** Schedules start and end reminders; blocking itself remains driven by the Protection Core. */
object NotificationScheduler{
    fun schedule(context:Context,s:BlockSchedule){cancel(context,s);val now=System.currentTimeMillis();val start=nextOccurrence(s,true,now);scheduleAlarm(context,s,start,"start");val end=nextOccurrence(s,false,now);scheduleAlarm(context,s,end,"end")}
    fun cancel(context:Context,s:BlockSchedule){val alarm=context.getSystemService(AlarmManager::class.java);listOf("start","end").forEach{type->alarm.cancel(pending(context,s,type))}}
    private fun scheduleAlarm(context:Context,s:BlockSchedule,at:Long,type:String){if(at<=0)return;context.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending(context,s,type))}
    private fun pending(context:Context,s:BlockSchedule,type:String):PendingIntent=PendingIntent.getBroadcast(context,(s.id.hashCode()*31+type.hashCode()),Intent(context,AppBlockNotificationReceiver::class.java).apply{putExtra("scheduleId",s.id);putExtra("type",type);putExtra("title",s.name);putExtra("message",if(type=="start")"Your focus schedule is starting now." else "Your focus schedule is ending now.")},PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    private fun nextOccurrence(s:BlockSchedule,start:Boolean,now:Long):Long{val tz=TimeZone.getTimeZone(s.timezoneId);val base=Calendar.getInstance(tz).apply{timeInMillis=now};if(s.oneTimeDate!=null){val p=s.oneTimeDate.split("-").mapNotNull(String::toIntOrNull);if(p.size!=3)return -1;val c=Calendar.getInstance(tz).apply{set(p[0],p[1]-1,p[2],if(start) s.startMinutes/60 else s.endMinutes/60,if(start) s.startMinutes%60 else s.endMinutes%60,0);set(Calendar.MILLISECOND,0);if(!start&&s.startMinutes>s.endMinutes)add(Calendar.DAY_OF_YEAR,1)};return if(c.timeInMillis>now)c.timeInMillis else -1}
        for(i in 0..7){val c=(base.clone() as Calendar).apply{add(Calendar.DAY_OF_YEAR,i);set(Calendar.HOUR_OF_DAY,if(start) s.startMinutes/60 else s.endMinutes/60);set(Calendar.MINUTE,if(start) s.startMinutes%60 else s.endMinutes%60);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)};if(c.timeInMillis<=now)continue;val day=c.get(Calendar.DAY_OF_WEEK);if(start&&s.days.contains(day))return c.timeInMillis;if(!start){val activeEndDay=if(s.startMinutes>s.endMinutes){if(day==Calendar.SUNDAY)Calendar.SATURDAY else day-1}else day;if(s.days.contains(activeEndDay))return c.timeInMillis}}
        return -1}
}
