# App Block 2.0 — Required Real-Device Validation

The source can be statically checked here, but Android service behavior must be validated on physical devices.

## Protection
- Enable Accessibility and Usage Access. Open a blocked app from launcher, notification, recents, share target and app shortcut.
- Disable Accessibility while a schedule is active; confirm App Block reports protection interruption instead of claiming success.
- Reboot with an active schedule; confirm rules and notifications recover.

## Time rules
- Test daily limit at 1 minute below, exactly at, and above the limit.
- Test 22:00–02:00 schedules across midnight.
- Test timezone change and device clock change.
- Test overlapping schedules are rejected.

## Sessions
- Start a 25-minute protected session. Confirm rule edits are unavailable.
- Start a configured break. Confirm app/website blocking relaxes during the break while configuration remains locked.
- Kill/recreate the app process during a timer and verify timer recovery.

## Website rules
- Test exact domain and subdomain.
- Test a look-alike domain such as notexample.com against example.com and confirm it is not blocked by that rule.
- Test multiple supported browsers.

## Usage/app discovery
- Compare App Block usage with Android Settings > Digital Wellbeing for several apps.
- Confirm a non-launcher package visible through UsageStats can be selected when the package is legitimately visible.

## Backup
- Export, clear, restore and verify blocklists, schedules, goals, sessions and history.
- Test wrong backup password.

## OEM testing
- Test at least one stock Android device and one OEM with aggressive background restrictions.
- Confirm battery warnings and recovery instructions are truthful.
